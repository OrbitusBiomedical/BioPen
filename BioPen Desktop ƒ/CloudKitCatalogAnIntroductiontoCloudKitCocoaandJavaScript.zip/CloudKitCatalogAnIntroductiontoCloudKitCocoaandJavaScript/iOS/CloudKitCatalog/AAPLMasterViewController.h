/*
    Copyright (C) 2015 Apple Inc. All Rights Reserved.
    See LICENSE.txt for this sample’s licensing information
    
    Abstract:
    This is the master view controller that pushes other CloudKit Catalog view controllers onto the view view controller hiearchy.
*/

@import UIKit;

@interface AAPLMasterViewController : UITableViewController

@end

